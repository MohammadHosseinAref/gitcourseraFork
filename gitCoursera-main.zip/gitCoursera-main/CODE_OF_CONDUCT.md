CODE_OF_CONDUCT file
I have added a CODE_OF_CONDUCT.md file to the repository. This document establishes clear expectations for participant behavior within the project community, promoting a respectful and inclusive environment for all contributors.
